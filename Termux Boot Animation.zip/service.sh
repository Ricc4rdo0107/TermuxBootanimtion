#!/system/bin/sh
MODDIR=${0%/*}
INFO=/data/adb/modules/.ROG-files
MODID=ROG
LIBDIR=/system
MODPATH=/data/adb/modules/ROG
prop_process $MODPATH/common/propsoss.prop
